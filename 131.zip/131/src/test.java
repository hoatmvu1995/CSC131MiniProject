
public class test {
	
	public test() {
		
	}
	
	public String toString() {
			return "test";
	}
	
	
}
